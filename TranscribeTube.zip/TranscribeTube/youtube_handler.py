import yt_dlp
import os
import asyncio
import logging
from typing import Optional

logger = logging.getLogger(__name__)

async def download_audio(url: str) -> Optional[str]:
    """
    Download audio from YouTube video.
    Returns the path to the downloaded audio file.
    """
    output_template = "downloads/%(id)s.%(ext)s"

    # Create downloads directory if it doesn't exist
    os.makedirs("downloads", exist_ok=True)

    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'wav',
            'preferredquality': '192',
        }],
        'outtmpl': output_template,
        'quiet': True,
        'no_warnings': True,
    }

    try:
        logger.info(f"Starting download for URL: {url}")
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # Get video info first
            info = ydl.extract_info(url, download=False)
            video_id = info['id']
            logger.info(f"Video ID: {video_id}, duration: {info.get('duration', 'unknown')}s")

            # Download the audio
            ydl.download([url])
            audio_path = f"downloads/{video_id}.wav"

            if os.path.exists(audio_path):
                logger.info(f"Successfully downloaded audio to: {audio_path}")
                return audio_path
            else:
                logger.error(f"Audio file not found at expected path: {audio_path}")
                return None

    except Exception as e:
        logger.error(f"Failed to download video: {str(e)}")
        raise Exception(f"Failed to download video: {str(e)}")