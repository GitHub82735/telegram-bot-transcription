import speech_recognition as sr
import asyncio
import logging
from typing import Optional

logger = logging.getLogger(__name__)

async def transcribe_audio(audio_path: str) -> Optional[str]:
    """
    Transcribe audio file to text using Google Speech Recognition.
    """
    recognizer = sr.Recognizer()

    try:
        logger.info(f"Starting transcription for file: {audio_path}")

        def transcribe():
            with sr.AudioFile(audio_path) as source:
                # Adjust for ambient noise
                logger.info("Adjusting for ambient noise...")
                recognizer.adjust_for_ambient_noise(source)
                # Record audio to memory
                logger.info("Recording audio to memory...")
                audio = recognizer.record(source)
                # Perform the transcription
                logger.info("Starting speech recognition...")
                return recognizer.recognize_google(audio)

        # Run the CPU-intensive transcription in a thread pool
        loop = asyncio.get_event_loop()
        transcription = await loop.run_in_executor(None, transcribe)

        logger.info(f"Successfully transcribed audio. Length: {len(transcription)} characters")
        return transcription

    except sr.UnknownValueError:
        logger.error("Speech Recognition could not understand the audio")
        raise Exception("Speech Recognition could not understand the audio")
    except sr.RequestError as e:
        logger.error(f"Could not request results from Speech Recognition service: {str(e)}")
        raise Exception(f"Could not request results from Speech Recognition service: {str(e)}")
    except Exception as e:
        logger.error(f"Error transcribing audio: {str(e)}")
        raise Exception(f"Error transcribing audio: {str(e)}")