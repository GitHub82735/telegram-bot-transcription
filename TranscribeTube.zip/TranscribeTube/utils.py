import re
import os
from typing import Optional

def is_valid_youtube_url(url: str) -> bool:
    """
    Validate YouTube URL format.
    Supports standard YouTube URLs, short URLs, and mobile URLs.
    """
    youtube_regex = (
        r'(https?://)?(www\.)?(youtube|youtu|youtube-nocookie)\.(com|be)/'
        '(watch\?v=|embed/|v/|.+\?v=)?([^&=%\?]{11})'
    )
    
    match = re.match(youtube_regex, url)
    return bool(match)

def cleanup_files(audio_path: Optional[str]) -> None:
    """
    Clean up downloaded files after processing.
    """
    try:
        if audio_path and os.path.exists(audio_path):
            os.remove(audio_path)
    except Exception as e:
        # Log error but don't raise - this is cleanup
        print(f"Error cleaning up files: {str(e)}")
