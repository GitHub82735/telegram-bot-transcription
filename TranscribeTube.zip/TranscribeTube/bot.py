import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from youtube_handler import download_audio
from transcriber import transcribe_audio
from utils import is_valid_youtube_url, cleanup_files
import os

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Bot token
TOKEN = "8191487892:AAEdaDeZ2EwBLA90RrjU1nuR0nkfitpZo5o"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    welcome_message = (
        "👋 Welcome to YouTube Transcriber Bot!\n\n"
        "Send me a YouTube video URL and I'll create a verbatim transcription.\n"
        "Supported formats:\n"
        "- Regular YouTube URLs\n"
        "- Short URLs (youtu.be)\n"
        "- Mobile URLs\n\n"
        "Just paste the URL and I'll provide the complete, word-for-word transcription!\n\n"
        "⚠️ Note: Videos should be under 10 minutes for best results."
    )
    await update.message.reply_text(welcome_message)
    logger.info(f"Start command received from user {update.effective_user.id}")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /help is issued."""
    help_text = (
        "🎯 How to use this bot:\n\n"
        "1. Copy a YouTube video URL\n"
        "2. Paste it in the chat\n"
        "3. Wait for the complete transcription\n\n"
        "⚠️ Notes:\n"
        "- Videos should be under 10 minutes\n"
        "- Audio must be clear for accurate word-for-word transcription\n"
        "- Supported languages: English\n"
        "- You'll receive the exact transcription without any summarization"
    )
    await update.message.reply_text(help_text)
    logger.info(f"Help command received from user {update.effective_user.id}")

async def process_video(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Process the YouTube video URL and return transcription."""
    message = update.message.text
    chat_id = update.message.chat_id
    user_id = update.effective_user.id
    logger.info(f"Processing video request from user {user_id} with URL: {message}")

    # Initialize status message and audio path
    status_message = None
    audio_path = None

    try:
        if not is_valid_youtube_url(message):
            await update.message.reply_text(
                "❌ Please send a valid YouTube URL.\n"
                "Examples:\n"
                "✅ https://youtube.com/watch?v=xxxxx\n"
                "✅ https://youtu.be/xxxxx"
            )
            return

        # Send processing message
        status_message = await update.message.reply_text(
            "🎵 Downloading audio...\n"
            "This might take a few moments depending on the video length."
        )

        # Download audio
        try:
            audio_path = await download_audio(message)
            if not audio_path:
                raise Exception("Failed to download audio - no file was created")
        except Exception as e:
            error_msg = str(e)
            if "Video unavailable" in error_msg:
                raise Exception("This video is unavailable or private")
            elif "copyright" in error_msg.lower():
                raise Exception("This video is not accessible due to copyright restrictions")
            else:
                raise Exception(f"Failed to download video: {error_msg}")

        await status_message.edit_text(
            "🎯 Transcribing audio...\n"
            "This process may take a few minutes."
        )

        # Transcribe audio
        try:
            transcription = await transcribe_audio(audio_path)
            if not transcription:
                raise Exception("No transcription was generated")
        except Exception as e:
            error_msg = str(e)
            if "could not understand" in error_msg.lower():
                raise Exception("Could not understand the audio. Please ensure the video has clear speech.")
            else:
                raise Exception(f"Transcription failed: {error_msg}")

        # Send transcription in chunks if it's too long
        if len(transcription) > 4096:
            await status_message.edit_text("📝 Sending complete transcription in multiple parts...")
            for i in range(0, len(transcription), 4096):
                chunk = transcription[i:i + 4096]
                # Add header only to first chunk
                if i == 0:
                    chunk = "📝 Complete transcription:\n\n" + chunk
                await context.bot.send_message(chat_id=chat_id, text=chunk)
        else:
            await context.bot.send_message(
                chat_id=chat_id,
                text="📝 Complete transcription:\n\n" + transcription
            )

        # Cleanup
        cleanup_files(audio_path)
        if status_message:
            await status_message.delete()

        logger.info(f"Successfully processed video for user {user_id}")

    except Exception as e:
        logger.error(f"Error processing video for user {user_id}: {str(e)}")
        error_message = (
            f"❌ {str(e)}\n\n"
            "If this error persists, please:\n"
            "1. Check if the video is public and available\n"
            "2. Try a shorter video (under 10 minutes)\n"
            "3. Ensure the video has clear speech"
        )
        await update.message.reply_text(error_message)
        if status_message:
            await status_message.delete()

        # Cleanup in case of error
        if audio_path:
            cleanup_files(audio_path)

def main() -> None:
    """Start the bot."""
    # Create application
    application = Application.builder().token(TOKEN).build()

    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, process_video))

    # Start the bot
    logger.info("Starting bot...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()